// dev.js - don't commit

module.exports = {
  GAS_PRICE: 10000000000,
  GAS_LIMIT: 30000,
  GAS_FEE_AMOUNT: '0.002',
  DB_CONNECTION_STRING:
    'mongodb+srv://dev:Noo3eeYu3zua_woh9Ce7Veep2@dg-dev-azure.iva4f.mongodb.net/DG_Dev?retryWrites=true&w=majority',
  REDIS_CONNECTION_STRING:
    'redis://:3OlxYiSbj96ScoRF8IsLC2mMKrkvCUObBAzCaPhkFF4=@redis-dg-dev.privatelink.redis.cache.windows.net:6379/',
  JWT_ACCESS_TOKEN_SECRET:
    '58728c03a1d1ae5117b4c691abe57720d7b7cc326a5368b573e28807d9d33df98b27ccd6fc6ef6ddb281bb705c9b67fac0052c39edf3c7a57849ad9360733c80',
};
